<?php

namespace controllers;
use \Controller;

class MainPageController extends Controller {

	public $showUsersList = true;

    public function doInit() {
        if ($this->loggedIn) {
			
		}
    }
}
