<?php

namespace controllers;
use \Controller;

use \models\User;

class TeasController extends Controller {

    public function doInit() {
		
    }
}
