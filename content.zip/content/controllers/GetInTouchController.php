<?php

namespace controllers;
use \Controller;

use \User;

class GetInTouchController extends Controller {

    public function doInit() {
    
    }
}
