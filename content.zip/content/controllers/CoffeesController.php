<?php

namespace controllers;
use \Controller;

use \models\User;

class CoffeesController extends Controller {

    public function doInit() {
		
    }
}
