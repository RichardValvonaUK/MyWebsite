<?php

namespace controllers;
use \Controller;

class ExitController extends Controller {

    public function doInit() {
		
    }
}
