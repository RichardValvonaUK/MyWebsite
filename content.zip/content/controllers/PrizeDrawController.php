<?php

namespace controllers;
use \Controller;

class PrizeDrawController extends Controller {

    public function doInit() {
		
    }
}
