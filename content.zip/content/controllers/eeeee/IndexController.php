<?php

namespace controllers\eeeee;
use \Controller;

class IndexController extends Controller {

	public $showPageSlides = true;

    public function doInit() {
        if ($this->loggedIn) {
			
		}
    }
}
