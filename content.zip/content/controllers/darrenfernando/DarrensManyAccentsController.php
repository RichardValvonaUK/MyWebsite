<?php

namespace controllers\darrenFernando;
use \Controller;

use \models\User;

class DarrensManyAccentsController extends Controller {

    public function doInit() {
	    
    }
}
