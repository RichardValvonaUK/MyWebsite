<?php

namespace controllers;
use \Controller;

use \models\User;

class AboutController extends Controller {

    public function doInit() {
    
    }
}
