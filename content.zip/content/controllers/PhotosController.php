<?php

namespace controllers;
use \Controller;

use \models\User;

class PhotosController extends Controller {

    public function doInit() {
		
    }
}
