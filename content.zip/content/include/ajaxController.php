<?php

abstract class AjaxController extends Controller {}
