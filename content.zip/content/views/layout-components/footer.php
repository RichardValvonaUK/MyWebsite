<div class="footer-content width">
	<div>
		
	</div>
	<div class="footer-bottom">
		<p>&copy; Copyright <?php echo date("Y"); ?>. <a href="http://www.richardvalvona.com">Richard Valvona</a></p>
	</div>
</div>
