<div class="title-and-menu">
	<span class="page-title">Richard Valvona's Very Own Website</span>
	<span class="social-network-links">
		<?php echo URLS::absLink(Images::create('autoheight', '1464388115_facebook.png', null, null),
			'https://www.facebook.com/richard.valvona',
			null
		); ?>
		<?php echo URLS::absLink(Images::create('autoheight', '1464387080_instagram.png', null, null),
			'https://www.instagram.com/m_r_robin/',
			null
		); ?>
		<?php echo URLS::absLink(Images::create('autoheight', '1464387946_twitter_2.png', null, null),
			'https://twitter.com/RichardValvona',
			null
		); ?>
		<?php echo URLS::absLink(Images::create('autoheight', '1464599692-youtube-square-social-media.png', null, null),
			'https://www.youtube.com/channel/UC_Dnr4KatK04R7TG_xuVG3Q/videos',
			null
		); ?>
	</span>
</div>
