<div>
	<?php echo URLS::jsLink("Edit page...",
		'onclick="editView(\'' . strtolower($controller->url) . '\');"',
		null); ?>
</div>
