<ul id="left-users-list">
	<li>
		<div style="display: inline-block; font-weight: bold; background: #f00; width: auto; margin: auto;">New (2)</div>
	</li><!--
	--><li class="user"><span>Cherry</span>
		<ul>
			<li class="subject"><span>Out and about near Sandown</span></li>
			<li class="subject"><span>Barbecue at the beach</span></li>
		</ul>
	</li><!--
	--><li class="user"><span>Bella</span>
		<ul>
			<li class="subject"><span>Barbecue at the beach</span></li>
			<li class="subject"><span>Barbecue at the beach</span></li>
		</ul>
	</li><!--
	--><li class="user"><span>Jill</span>
		<ul>
			<li class="subject"><span>Barbecue at the beach</span></li>
			<li class="subject"><span>Barbecue at the beach</span></li>
		</ul>
	</li><!--
	--><li class="user"><span>Chloe</span>
		<ul>
			<li class="subject"><span>Barbecue at the beach</span></li>
			<li class="subject"><span>Barbecue at the beach</span></li>
		</ul>
	</li>
</ul>
