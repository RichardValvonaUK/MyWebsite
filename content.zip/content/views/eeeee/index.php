<section class="content-wrapper">
	<section class="centered-content">
		<article>
			<h2>Welcome to Simple Dating</h2>
			<p>Simple Dating is a different approach to online-dating. Instead of the typical profile-based system seen on most sites, here we omit user-profiles altogether and instead you see dates.
			
			To see how it works in detail, click here.
			
			
			
			The concept is very simple. The main page is a list of dates. You simply post a date you would like to do and then other users can click on the date and send you a message if they want to do that date with you. Once a user sends you a message, an alert will show up in the webpage and you can reply to them. Once you open up a 
			
			As 
			
			</p>
			
			
			On Simple Dating, you register as a user like usual and verify your account with the supplied email. After that, the next step is uploading a picture of yourself. Unlike a lot of sites, a picture is mandatory.
			
			The next step is the verification phase. There are two ways you can do this. If you have a Facebook account then you can register as a Facebook user
		</article>
	</section>
</section>
