<section class="content-wrapper">
	<section class="centered-content">
		<article>
			<h1>Photos</h1>
			<p>
			This page is not yet complete and will be updated not too far into the future. For now, I have a page of a few birds I've seen in the UK and there will be a USA version too of birds I've seen out there. Other photo pages will also be added as this site develops.
			</p>
		</article>
	</section>
</section>
