<section class="left-content">
	<article>
		<p><span style="color:#000000;"><strong>Thank you, your participation for today is complete. Check your timetable so you know when to log in next.</strong></span></p>
	</article>
</section>
<section class="right-sidebar-content extra-narrow">
	<p><a class="button" href="<?php echo URLS::link('/index'); ?>">Return to Homepage</a></p>
	<p><a class="button" href="http://www.healinglotusfoundation.com/forumhomepage.html">Visit Forum</a></p>
</section>
