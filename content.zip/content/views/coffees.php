<section class="content-wrapper">
	<section class="centered-content">
		<article>
			<h2>Coffees</h2>
			<p>Coffees page
			
			</p>
		</article>
	</section>
</section>
