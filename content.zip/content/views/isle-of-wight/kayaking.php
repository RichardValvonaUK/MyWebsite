<h2>Kayaking on the Isle of Wight</h2>




<?php echo \Images::create('right-floating-image', 'whale-cruise-picture-on-boat.jpg', null, null); ?>
<p>

</p>
<h3>Whale Cruise to San Juan Island</h3>
<p>

</p>
<p>
</p>
<h3>So, what did we see?</h3>
<p>
</p>
<h3>On San Juan Island</h3>
<?php echo \Images::create('right-floating-image', 'entering-friday-harbour.jpg', null, null); ?>
<?php echo \Comps::clearWrap(); ?>
<p>
</p>
<?php echo \Comps::clearWrap(); ?>
<div class="date-stamp">Posted on Saturday 27th August 2016</div>
