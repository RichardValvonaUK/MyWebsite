<h3>Woodpigeon</h3>
<i>Lat: Columba palumbus; Rus: Вяхирь / витютень</i><br/><br/>
<?php echo \Images::create('left-floating-image', 'woodpigeon.jpg', 400, null); ?>
<p>
Oh yeah. One of my favourite birds... not! Well they are alright I suppose and you certainly can eat them cooked in red wine.
<br/><br/>
In most of the UK, these pigeons are everywhere and you won't need to look very hard to find one, even in the towns. Aparently in mainland Europe, they aren't as common although I cannot confirm this.
<br/><br/>
I remember a good 10 years ago when they used to be very shy and fly off when I was even metres away from them. Now though, they let you get a lot nearer, like the one in this picture.
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
