<h3>Black-headed Gull</h3>
<i>Lat: ; Rus: </i><br/><br/>
<?php echo \Images::create('right-floating-image', 'black-headed-gull.jpg', 400, null); ?>
<p>
<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
