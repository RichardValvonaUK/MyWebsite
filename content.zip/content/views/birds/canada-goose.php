<h3>Canada Goose</h3>
<i>Lat: Branta canadensis; Rus: Канадская казарка</i><br/><br/>
<?php echo \Images::create('right-floating-image', 'canada-geese.jpg', 400, null); ?>
<p>

<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
