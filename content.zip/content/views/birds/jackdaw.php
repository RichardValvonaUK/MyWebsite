<h3>Jackdaw</h3>
<i>Lat: ; Rus: </i><br/><br/>
<?php echo \Images::create('left-floating-image', 'jackdaw.jpg', 400, null); ?>
<p>
<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
