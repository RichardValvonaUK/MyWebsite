<h3>Starling</h3>
<i>Lat: ; Rus: </i><br/><br/>
<?php echo \Images::create('right-floating-image', 'starling.jpg', 400, null); ?>
<p>
Very noisy things these are. If you hear them then you'll know it's them. Starlings can make a wide variety of noises which includes mimicking other birds. I've never witnessed this personally but one thing I do remember is once when I was living at home, one makes a noise like a telephone ringing.
<br/><br/>
When I was young, I used to confuse them for blackbirds. They can sometimes be very dark and to the point of being almost black. However, starlings have lots of white "stars" on them (I guess that's where the name comes from) which makes it easy enough to tell them apart.
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
