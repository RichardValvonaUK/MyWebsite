<h3>Carrion Crow</h3>
<i>Lat: ; Rus: </i><br/><br/>
<?php echo \Images::create('right-floating-image', 'carrion-crow.jpg', 400, null); ?>
<p>
<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
