<h3>Mute Swan</h3>
<i>Lat: Cygnus olor; Rus: Лебедь-шипун</i><br/><br/>
<?php echo \Images::create('left-floating-image', 'mute-swan.jpg', 400, null); ?>
<p>
Of the three species of British swan, this is by far the most common and familiar to pretty much everyone. In my home-town of Ryde, there is a canoe-lake which always has swans which unfortunately also poop on the path surrounding it. They are scary things and are known to be able to break your arm with their wing if you wind them up.
<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
