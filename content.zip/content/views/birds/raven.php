<h3>Raven</h3>
<i>Lat: Corvus corax; Rus: Ворон</i><br/><br/>
<?php echo \Images::create('right-floating-image', 'raven.jpg', 400, null); ?>
<p>

<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
