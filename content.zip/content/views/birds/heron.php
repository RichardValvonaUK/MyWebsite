<h3>Grey Heron</h3>
<i>Lat: Ardea cinerea; Rus: Серая цапля</i><br/><br/>
<?php echo \Images::create('right-floating-image', 'heron-on-post.png', 400, null); ?>
<p>
Herons are one of those birds which you see standing for what seems like hours and hours in the same spot stalking their prey with their beak and long neck. Having lived by the sea for most of my years, these have been a fairly common site although dusk always seems to be the best time to see them when presumably the fish are most abundant.
<br/><br/>

<br/><br/>
These birds always remind me of going to my grandparents house. They have a small pond with fish in it and the heron sometimes sits on their neighbour's roof for ages looking down.
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
