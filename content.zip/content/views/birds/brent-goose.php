<h3>Brent Goose</h3>
<i>Lat: ; Rus: </i><br/><br/>
<?php echo \Images::create('left-floating-image', 'brent-geese.jpg', 400, null); ?>
<p>
<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
