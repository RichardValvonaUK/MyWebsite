<h3>Mallard Duck</h3>
<i>Lat: Anas platyrhynchos; Rus: Кряква</i><br/><br/>
<?php echo \Images::create('left-floating-image', 'mallard-ducks.jpg', 400, null); ?>
<p>

<br/><br/>
<br/><br/>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
