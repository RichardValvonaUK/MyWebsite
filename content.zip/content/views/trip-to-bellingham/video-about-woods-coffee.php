<h2>Woods Coffee, Bellingham - Video</h2>
<p>
My second video during my trip to Bellingham. This time I talk about Woods Coffee. Feel free to watch and leave a comment at the bottom! Also, if you haven't watched the <?php echo \URLS::localLink('first video about my trip, then you can see it here', 'trip-to-bellingham/video-about-bellingham', null); ?>
</p>
<iframe class="embedded-youtube" width="854" height="480" src="https://www.youtube.com/embed/C2uEZHus7jM" frameborder="0" allowfullscreen></iframe>
