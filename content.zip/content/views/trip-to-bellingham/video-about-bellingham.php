<h2>My experience of Bellingham - Video</h2>
<p>
I have now uploaded a video about my trip to Bellingham and what differences I've noticed here. Feel free to watch and leave a comment at the bottom! Also, I now have a <?php echo \URLS::localLink(' second video about Woods Coffee.', 'trip-to-bellingham/video-about-woods-coffee', null); ?>
</p>
<iframe class="embedded-youtube" width="854" height="480" src="https://www.youtube.com/embed/fttUJZHPChE" frameborder="0" allowfullscreen></iframe>
<div class="date-stamp">Posted on Memorial Day - Monday 30th May 2016</div>
