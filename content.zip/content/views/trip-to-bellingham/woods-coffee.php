<h2>Woods Coffee</h2>
<p>
If you visit Bellingham or any of the nearby cities (yes, they don't call them towns like we do back in the UK), then a visit is not complete without going at least once into Woods Coffee shop.
</p>
<p>

<p>
</p>
<?php echo \Comps::clearWrap(); ?>
<br /><br />
