<section class="content-wrapper">
	<section class="centered-content">
		<article>
			<h2>Teas</h2>
			<p>Teas page
			
			</p>
		</article>
	</section>
</section>
