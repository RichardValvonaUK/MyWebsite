<?php

class Comps {
	public static function clearWrap() {
		return "<span class=\"clear-wrap\" /></span>";
	}
}
