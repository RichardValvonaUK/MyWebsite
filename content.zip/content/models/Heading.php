<?php

class Heading {
	public $classAtt;
	public $title;

	public function __construct($classAtt, $title) {
		$this->classAtt = $classAtt;
		$this->title = $title;
	}
}
